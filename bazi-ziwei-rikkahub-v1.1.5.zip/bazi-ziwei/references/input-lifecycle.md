# V1.1.2 输入与结果文件的生命周期

知识检索直接使用参数，排盘默认从标准输入读取 JSON。普通流程不创建 knowledge-query*.json 或 input.json。各模式沿用原输入契约，计算算法及引擎版本没有变化。

## 知识检索

```sh
sh /skills/bazi-ziwei/scripts/mobile.sh --knowledge --query '七夕' --limit 3
sh /skills/bazi-ziwei/scripts/mobile.sh --knowledge --topic folk-liji-hunyi
```

query 与 topic 二选一；query 为 1–200 字，limit 为 1–10 的整数，默认 5。返回结果在 stdout，不创建查询输入或检索结果文件。将关键词作为独立且正确引用的参数，不使用字符串拼接或 eval；含单引号的值按 POSIX shell 转义。

## 默认排盘：标准输入

以下是可运行的合成八字示例。正式运行必须替换为本次已确认且符合契约的完整 JSON，不沿用示例资料。

```sh
sh /skills/bazi-ziwei/scripts/mobile.sh --stdin --out /workspace/bazi-ziwei-reports/demo/result <<'BAZI_INPUT'
{"mode":"bazi","birth":{"calendar":"solar","date":"1994-02-13","time":"09:15","gender":"female","timezone":"Asia/Shanghai"}}
BAZI_INPUT
sh /skills/bazi-ziwei/scripts/mobile.sh --verify /workspace/bazi-ziwei-reports/demo/result/chart.json
```

workspace_shell 的 command 使用这个带引号的 here-document，JSON 单独放在开始和结束标记之间。正文是合法 JSON，换行等字符串内容必须按 JSON 编码；结束标记独占一行。引号保护的标记防止正文里的美元符号、反引号或命令替换被 shell 执行。不要同时调用 workspace_write_file 创建 input.json。

该入口支持 bazi、ziwei、both、divination、relationship、time_compare。出生、六爻、关系及候选字段分别使用既有输入契约。普通追问继续复用已校验的结果。

## 必须使用文件时

```sh
sh /skills/bazi-ziwei/scripts/mobile.sh --temp-input /workspace/bazi-ziwei-reports/TASK/input.json --out /workspace/bazi-ziwei-reports/TASK/result
sh /skills/bazi-ziwei/scripts/mobile.sh --knowledge --temp-input /workspace/bazi-ziwei-reports/TASK/knowledge-query.json
```

--temp-input 表明该文件是本次调用拥有的临时输入，必须作为输入选项的第一项；知识模式排在 --knowledge 后。Node 的 finally 在成功、JSON/参数错误、计算错误、依赖加载或写入异常后清理该文件；正常响应的 temporary_input_removed 为 true。手机 shell 另有 EXIT 与信号 trap，即使缺少 Node 也清理已接收的临时文件。CLI 还处理 SIGINT、SIGTERM、SIGHUP。

技能资源、随包示例、目录、符号链接及 chart.json、comparison.json、report.md、report.html、reading.md 不能标记为临时输入。执行过程中被替换或修改的文件保留并返回 cleanup_error。清理失败会返回非零退出码，不当作已经成功清理。程序只操作明确传入的这个文件，不按名称通配删除其他任务资料。

--input PATH 明确保留可复用的输入或用户主动保存的文件，包括执行失败时；用于随包示例的复现。新临时输入不要用这个入口。不要自动清理用户已有的输入集合、历史 chart 或未确认用途的 JSON。

finally 和 trap 适用于能够正常执行清理的退出路径；系统强制杀进程、断电或没有删除权限时，不能保证清理完成。优先使用 --stdin 与直接检索参数，避免在这些情形下产生 Workspace 临时输入。该机制不是磁盘安全擦除。

## 有价值的结果

普通模式保留 chart.json；时辰对照另保留 comparison.json，用于后续追问、候选提取和程序重算。report.md、report.html 仅显式 --report / --render 生成，AI reading.md 仅在用户要求保存时写入。临时输入的清理不删除或改写这些结果。

chart.json 仍包含用于复算的规范输入和关系背景。因此本版减少的是多余临时副本，结果文件仍应按个人资料管理。用户要求删除某次结果时，按明确指定的任务清理；不能用全 Workspace 扫描代替。

## 疏文输入

`mobile.sh --shuwen --stdin` 默认仅返回文字，无中间 JSON，也无自动保存文稿。必须传文件时用 `--shuwen --temp-input PATH`，Node finally 与 shell EXIT/signal trap 负责清理；`--input` 明确保留。导出的 `shuwen.txt` 和 `shuwen.html` 受到结果文件保护，不可标为临时输入。独立入口与导出参数见 [疏文方法](shuwen-method.md)。
