---
name: bazi-ziwei
description: 用本地程序排八字、紫微斗数和六爻铜钱卦，出生时间不确定时比较候选盘，完成单人婚恋预测、双人合盘、对象画像、本人八字/紫微的年上/年下取象与亲密关系专题。支持疏文、表文与祭告文制作。默认在聊天中回复，用户需要时导出文件；附 67 个可检索知识主题（35 个术数主题、21 张民俗古籍卡、11 张方法与来源卡），支持传统禁忌、节俗、修行、房中术与双修的文献问答。
---

# 八字、紫微与六爻 · 程序排盘 Skill

RikkaHub Workspace 适配版 V1.1.5，包版本 1.1.5，目标客户端 2.5.6。八字/紫微引擎 0.4.0，六爻引擎 0.1.0，关系引擎 0.6.0，时辰对照引擎 0.5.0。知识修订 1.1.5-knowledge.1，原有民俗卡内容保留。计算由随包程序执行，解读依据已校验结果。

## 选择任务

- 生辰排盘用 `mode: bazi / ziwei / both`，输入见 [出生输入契约](references/input-schema.md)，解读见 [八字方法](references/bazi-method.md)和 [紫微方法](references/ziwei-method.md)。综合分析使用 both。逐年趋势读取 [年度关系方法](references/annual-relations.md)，将 annual 的显干/藏干十神、四柱关系与日支关系结合原局和大运解读。
- 出生时间未知、只记得范围或有几个候选时，用 `mode: time_compare`，先读取 [时辰对照方法](references/time-compare-method.md)。birth 不填 time；比较本人候选盘的一致项和变化项，综合分析用 both。
- 婚恋与合盘用 `mode: relationship`，见 [关系输入与方法](references/relationship-method.md)。单人填本人，双人按 a、b 顺序填写出生资料，背景写 context。
- 对象外形、体态、气质、风格、属相缘分与年上/年下见 [单人画像与年龄方法](references/partner-image-method.md)。只需本人资料，按问题加入 partner_image / zodiac / age_relation。年龄见 [有来源的单人年龄方法](references/partner-age-method.md)，八字柱位仅作辅助。
- 性能力与亲密关系专题、报告开关见 [年龄、亲密与按需报告](references/age-intimacy-output.md)。按所问范围展开，结合盘面和已有叙述。
- 一事一占用 `mode: divination`、`method: liuyao`，见 [六爻方法](references/liuyao-method.md)。用户实际提供六次摇卦与占时，第一次为初爻，最后一次为上爻。
- 写疏文、表文、烧纸祭告文或还愿祈愿文时，读取 [疏文制作方法](references/shuwen-method.md)。用 `mobile.sh --shuwen --stdin`，无需排盘；默认文稿在聊天中给出，需要保存或打印时才导出。按用途、对象、姓名、日期和用户原意写，缺项明确待填。
- 术数知识问答见 [知识库索引](references/knowledge-index.md)，民俗、禁忌、传统婚礼与古籍见 [来源卡索引](references/folklore-index.md)。修行、房中术与双修先读 [文献解读方法](references/folk-cultivation-method.md)，按具体原典语境解释；纯知识问答无需生辰。

新增程序与知识的采用范围见 [三项目参考与增补](references/project-adoption.md)。大运关系、紫微宫干四化及候选比较字段见 [大运与飞化方法](references/dayun-flying-method.md)。按当前问题读取资料；古籍短引先检索对应卡片。

## 收集输入

以下出生资料流程只适用于排盘与时辰对照；疏文、表文按其方法收集必要信息。复用已有资料，只补问影响计算的缺失项：出生日期、公/农历、排运安星所需 gender、时区；农历另需是否闰月。时间明确时收集时分；不确定时保留原范围或使用全天 unknown，转 time_compare，不补默认时刻。匿名标签即可。海外及历史日期按实际 IANA 时区或用户明确偏移解析。

用户出生资料与关系背景只用于当前任务的输入和计算文件，不写入技能、系统提示词、知识库或随包示例。开发复现问题使用独立合成数据；文件名和目录名不含姓名、生日或其他个人标识。

默认采用钟表时间；需要真太阳时验证或明确采用太阳时排八字时，读取 [真太阳时方法](references/true-solar-time.md)，核实出生地经度并记录来源，birth.time 仍填原始钟表记录，options.time_basis 选 true_solar。both 模式八字日时采用太阳钟面、紫微沿用钟表；年月与起运保持真实出生瞬间。没有可靠经度时先用 clock，不补造城市坐标。子时、换年和闰月使用 [输入契约](references/input-schema.md)中的配置。模型支持的计算字段与程序方法对应，新增方法需有可执行规则。问“现在/今年”时核实客户端日期后填写 target_date。

六爻输入为六组三枚铜钱或六个爻值 6/7/8/9。先核对正面=3、反面=2的记录约定与排列方向。缺记录时指导用户投掷；占时填写实际日期、时分与时区。

## 执行与校验

RikkaHub 调用 `use_skill`，参数 `name: "bazi-ziwei"`；path 使用本文件实际链接。完整 ZIP 包含程序和依赖，安装与运行时配置见 [手机安装说明](手机安装说明.md)。需绑定 Linux 工作区，使用 workspace_shell、workspace_write_file、workspace_read_file。

首次或工作区变化时自检：

```sh
sh /skills/bazi-ziwei/scripts/mobile.sh --check --self-test
```

缺少 Node 时按安装说明运行 [安装脚本](scripts/install-node.sh)，遵循客户端审批，安装 timeout 可设 600 秒。自检须 exitCode=0、timedOut=false、stdout.ok=true。

以下 chart.json 执行流程用于排盘；疏文按独立入口返回文本，只有要求导出时才创建文件。每次新计算选独立任务目录 `/workspace/bazi-ziwei-reports/TASK`，TASK 只含字母、数字、连字符。优先用 workspace_shell 的带引号 here-document 将本次合法 JSON 送入 --stdin，不创建 input.json；具体写法见 [输入生命周期](references/input-lifecycle.md)。计算与校验分别执行，timeout 可设 120 秒：

```sh
sh /skills/bazi-ziwei/scripts/mobile.sh --stdin --out /workspace/bazi-ziwei-reports/TASK/result
sh /skills/bazi-ziwei/scripts/mobile.sh --verify /workspace/bazi-ziwei-reports/TASK/result/chart.json
```

第一个命令必须附上含本次 JSON 的带引号 here-document，不能空运行。必须使用文件时，workspace_write_file 写到独立任务目录，再用 --temp-input PATH 自动清理；用户明确保留的输入或随包示例才用 --input。两个命令须成功，校验另须 recalculated=true。读取本次返回的 files；普通模式读取 chart.json，time_compare 还须 summary_verified=true，再优先读取 comparison.json，按需提取候选回查完整盘。失败时处理实际错误后再解读。输入、口径、候选范围与目标日期未变时复用已校验结果。

普通模式默认只生成 chart.json，time_compare 默认生成 chart.json 和 comparison.json 两个计算文件，直接在聊天中回答。只有用户明确要求文件报告时才 `--render` 或首次加 `--report`；用户需要保存 AI 解读时才写 reading.md。普通追问与详细解释仍在聊天中展开，保留原计算 JSON。

其他 Node.js 20+ 宿主可直接用 [排盘 CLI](scripts/run.cjs)。手机入口是 [mobile.sh](scripts/mobile.sh)，自检是 [preflight.cjs](scripts/preflight.cjs)。

## 解读与引用

八字解释读取 [子平理论核对](references/bazi-theory-audit.md)，先看月令、同五行通根与透干、再综合合冲岁运。大运同时读取藏干十神、pillar_relations 与 day_branch_relations；紫微按所问宫位读取 palace_stem_flying 的发出宫、落入宫与自化，分开生年及岁运四化。使用 theory_evidence、五虎遁/五鼠遁检查；五行分数不能直接定旺衰、格局或喜用。bazi_hour_stem_rule 默认 day_stem；library 只在明确采用旧库晚子时口径时选择。太阳时或节气边界复核标记命中时，按出生记录精度对照两侧候选。

开始解读时读取 [对话语气与示范](references/conversation-style.md)。默认温和直说，像熟悉命理、有判断的朋友。先回答当前问题，再自然解释关键盘面；画像转成日常描述，追问只展开新问到的点。单人年龄回查 age_relation.predictions 中本人的 R-A-AGE。

时辰对照先讲本次候选中一致的部分，再说明哪些判断随时辰变化。对象画像用共同标签给轮廓，年龄和紫微夫妻宫有分歧时按候选分支解释；候选数不当作概率，不认定最佳时辰。无法计算的时间段按具体错误说明，保留比较范围。

配偶星默认 auto 按传统排盘参数选财或官杀；用户指定 wealth / authority / all 时优先采用。all 分别解释两条主线。双人关系结合各自命盘与跨盘账本，具体方法见关系文档。

主要判断在数据中对应实际证据编号；普通聊天以自然语言解释，用户要核对时再展示编号。可用编号：八字 BZ-DAY、BZ-MONTH、BZ-REL-xxx；紫微按本案宫名找 ZW-Px；六爻 LY-BASE、LY-CHANGE、LY-TIME、LY-L1 至 LY-L6、LY-R1 至 LY-R6；关系按人物标 a:BZ-DAY、b:ZW-Px。数值、星曜、爻位与规则命中均取自本次程序结果。

知识按 [索引](references/knowledge-index.md)读取，可参考 [子平八字](references/knowledge/supe888-bazi-skills/topics/ziping-bazi.md)、[紫微](references/knowledge/supe888-bazi-skills/topics/ziwei-doushu.md)和 [六爻](references/knowledge/supe888-bazi-skills/topics/wenwang-liuyao.md)。参考文本经过清理，执行方式和输出篇幅由当前技能与用户需求决定。

离线检索直接传参，不创建查询文件：

```sh
sh /skills/bazi-ziwei/scripts/mobile.sh --knowledge --query '六爻' --limit 3
sh /skills/bazi-ziwei/scripts/mobile.sh --knowledge --topic wenwang-liuyao
```

知识记录对应 `KB:主题slug@f14a60b`；来源卡对应 FH-01 至 FH-21。聊天用资料名称与原始链接介绍出处，用户要核对时再附编号。文献与计算编号各有出处，来源见 [开源采用记录](references/relationship-sources.md)。

## 对话表达

按 [语气说明](references/conversation-style.md)回应。默认温和直说，用户可要求简洁判断或命理细讲。依据写进自然语言，普通追问接着聊；结尾停在当前答案或适用的建议上。延续按需报告流程，不添加固定免责声明或泛化说教。缺输入或计算错误时说明具体情况，不虚构数据或引文。
