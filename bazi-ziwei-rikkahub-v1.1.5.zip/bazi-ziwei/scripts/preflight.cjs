'use strict';
// 独立入口：先检查运行环境，再加载排盘依赖，错误仍能返回可读的 JSON。
function preflight({selfTest=false}={}) {
  const assert=require('node:assert/strict');
  assert.ok(Number(process.versions.node.split('.')[0])>=20,'需要 Node.js 20 或更新版本');
  assert.ok(process.versions.icu,'需要启用 ICU / Intl 的 Node.js');
  const {Temporal}=require('@js-temporal/polyfill');
  assert.equal(Temporal.ZonedDateTime.from('2000-01-01T12:00:00[Asia/Shanghai]').offset,'+08:00');
  assert.throws(()=>Temporal.ZonedDateTime.from('2024-03-10T02:30:00[America/New_York]',{disambiguation:'reject'}));
  const {build,validateArtifact}=require('./engine.cjs');
  const data=build({mode:'both',birth:{calendar:'solar',date:'2005-12-23',time:'08:37',gender:'male',timezone:'Asia/Shanghai'}});
  assert.deepEqual(data.bazi.chart.pillars.map(p=>p.ganzhi),['乙酉','戊子','辛巳','壬辰']);
  assert.equal(data.ziwei.chart.palaces.length,12);
  assert.equal(data.ziwei.calculations.palace_stem_flying.entries.length,48);assert.ok(data.bazi.chart.dayun.every(y=>Array.isArray(y.day_branch_relations)));
  validateArtifact(data);
  const solar=build({mode:'bazi',birth:{calendar:'solar',date:'1990-05-20',time:'14:30',gender:'male',timezone:'Asia/Shanghai',longitude:116.4},options:{time_basis:'true_solar'}});
  assert.equal(solar.normalized.utc_offset,'+09:00');assert.equal(solar.bazi.chart.day_hour_calculation_datetime,'1990-05-20T13:19:08.203');assert.ok(solar.bazi.calculations.theory_evidence.five_rats.matches);validateArtifact(solar);
  if(selfTest) {
    const lunar=build({mode:'both',birth:{calendar:'lunar',date:'2023-02-01',is_leap_month:true,time:'12:00',gender:'female',timezone:'Asia/Shanghai'}});
    assert.equal(lunar.normalized.solar_date,'2023-03-22');
    validateArtifact(lunar);
    const {makeReport}=require('./report.cjs');
    const report=makeReport(data);
    assert.ok(report.markdown.length>0 && report.html.length>0);
    const ly=require('./divination.cjs');
    const gua=ly.build({mode:'divination',method:'liuyao',question:'合成自检问题',casting:{lines:[9,9,9,9,9,9]},time:{date:'2005-12-23',time:'08:37',timezone:'Asia/Shanghai'}});
    assert.equal(gua.chart.base.name,'乾为天');assert.equal(gua.chart.changed.name,'坤为地');ly.validateArtifact(gua);
    const knowledge=require('./knowledge.cjs');const library=knowledge.verifyKnowledge();assert.equal(library.topics,35);assert.equal(library.folklore_topics,21);assert.equal(library.new_classical_verified,14);assert.equal(library.curated_topics,11);assert.equal(library.total_topics,67);assert.ok(knowledge.lookup({query:'双修',limit:10}).matches.some(t=>t.slug==='folk-xingming-shuangxiu'&&t.source_kind==='classical_primary_text'));
    const sw=require('./shuwen.cjs');const document=sw.build(require('../examples/shuwen-input.json'));assert.equal(document.status,'complete');assert.equal(document.calendar.solar_date,'2026-10-05');assert.equal(document.files.length,0);assert.ok(sw.makeHtml(document,'vertical').includes('flex-direction:row-reverse'));assert.equal(sw.documentDate({calendar:'lunar',date:'2023-02-01',is_leap_month:true}).solar_date,'2023-03-22');
    const rel=require('./relationship.cjs');const ageOnly=rel.build({mode:'relationship',chart_mode:'ziwei',question:'合成年龄规则自检',people:[{id:'a',birth:{calendar:'solar',date:'1994-02-13',time:'03:15',gender:'male',timezone:'Asia/Shanghai'}}],context:{topics:['age_relation']}});assert.equal(ageOnly.age_relation.predictions[0].input_scope,'single_natal_chart');assert.equal(ageOnly.age_relation.predictions[0].tendency,'younger');assert.equal(ageOnly.age_relation.predictions[0].ziwei.matches[0].reference.original_excerpt,'夫宜长妻宜少');rel.validateArtifact(ageOnly);const pair=rel.build(require('../examples/relationship-pair-input.json'));assert.equal(pair.comparison.bazi.pillar_matrix.length,16);assert.equal(pair.age_relation.predictions.length,2);assert.equal(pair.age_relation.predictions[0].input_scope,'single_natal_chart');assert.equal(pair.partner_images.length,2);rel.validateArtifact(pair);const rr=require('./relationship-report.cjs').makeReport(pair);assert.ok(rr.markdown.includes('双方结构对照')&&rr.html.length>0);
    const annual=build(require('../examples/annual-relations-input.json'));const year=annual.bazi.chart.annual.find(y=>y.lichun_cycle_year===2030);assert.equal(year.stem_ten_god,'比肩');const fire=year.day_branch_relations.find(r=>r.type==='三合'&&r.symbols==='寅午戌');assert.ok(fire&&fire.natal_group_present&&fire.pillars.includes('BZ-ANNUAL-2030'));validateArtifact(annual);
    const tc=require('./time-compare.cjs');const comparison=tc.build({mode:'time_compare',chart_mode:'both',birth:{calendar:'solar',date:'1995-01-15',gender:'female',timezone:'Asia/Shanghai'},time_uncertainty:{type:'candidates',times:['08:30','09:30']}});assert.equal(comparison.candidates.length,2);assert.ok(comparison.comparison.stable_field_ids.includes('TC-BZ-DAY'));assert.ok(comparison.comparison.variable_field_ids.includes('TC-BZ-HOUR'));tc.validateArtifact(comparison);tc.validateSummary(tc.summary(comparison),comparison);assert.ok(require('./time-compare-report.cjs').makeReport(comparison).markdown.includes('随候选时间变化'));
  }
  return {ok:true,adapter:'rikkahub-workspace/v1.1.5',engine_version:'0.4.0',divination_engine:'liuyao/0.1.0',relationship_engine:'relationship/0.6.0',time_compare_engine:'time-compare/0.5.0',shuwen_engine:'shuwen/0.1.0',node:process.versions.node,icu:process.versions.icu,tz_database:process.versions.tz||'not_reported',engines:data.provenance.engines,checked:['true solar NOAA fixture and historical DST','five-rats consistency','timezone','DST rejection','bazi fixed fixture','ziwei 12 palaces','recalculation',...(selfTest?['lunar leap month','report rendering','liuyao moving lines','35-topic knowledge integrity','21 sourced folklore cards','14 classical passage records','annual four-pillar and spouse-palace relations','dayun hidden gods and relations','48 palace-stem flying transformations','11 curated method/classical topics','shuwen draft without saved inputs, calendar conversion and print HTML','relationship 16-pair matrix and recalculation','single-person sourced Ziwei age cues and auxiliary Bazi positions','bazi-ziwei-zodiac partner image','time uncertainty candidate comparison and verified summary']:[])]};
}
if(require.main===module) {
  try {
    if(process.argv.slice(2).some(x=>x!=='--self-test')) throw Error('用法：node scripts/preflight.cjs [--self-test]');
    console.log(JSON.stringify(preflight({selfTest:process.argv.includes('--self-test')})));
  } catch(e) {console.error(JSON.stringify({ok:false,error:e.message,action:'检查 Node.js 版本、完整技能 ZIP 和时区数据；不要用模型替代排盘。'}));process.exitCode=2;}
}
module.exports={preflight};
